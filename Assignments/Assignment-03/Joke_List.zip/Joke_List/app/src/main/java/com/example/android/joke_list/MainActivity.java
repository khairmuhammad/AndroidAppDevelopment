package com.example.android.joke_list;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> listItems = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    ListView list;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.txt);
        list = (ListView) findViewById(R.id.listView);

    }

    public void deleteData(String str) {
        ContentValues values = new ContentValues();
        values.put(CustomProvider.id,str);
        getContentResolver().delete(CustomProvider.CONTENT_URI, String.valueOf(values),null);
    }


    public void onClickAddJokes(View view) {
        ContentValues values = new ContentValues();
        values.put(CustomProvider.name, editText.getText().toString());
        getContentResolver().insert(CustomProvider.CONTENT_URI, values);
        Toast.makeText(getBaseContext(), "New Joke Inserted", Toast.LENGTH_LONG).show();
        editText.setText("");
    }

    public void onClickShowJokes(View view) {

        adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item,
                listItems);
        list.setAdapter(adapter);

        Cursor cursor = getContentResolver().query(
                Uri.parse("content://com.example.android.joke_list.CustomProvider/jokes"),
                null, null, null, null);

        listItems.removeAll(listItems);
        if (cursor.getCount() == 0) {
            // show message that no record found
            Toast.makeText(getBaseContext(), "No Jokes Found", Toast.LENGTH_LONG).show();
            return;
        }

        while (cursor.moveToNext()) {
            listItems.add(cursor.getInt(0)+" - "+cursor.getString(1));
        }

        adapter.notifyDataSetChanged();
    }

}
